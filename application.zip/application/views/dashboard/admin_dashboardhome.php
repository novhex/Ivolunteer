<div class="container" style="margin-top:70px;">

<div class="row">
	<div class="col-md-12 well">
	<div class="col-sm-4">
		   <div class="panel panel-info">
            <div class="panel-heading">
              <h3 class="panel-title"> <i class="fa fa-info"></i> Newly Registered Volunteers </h3>
            </div>
            <div class="panel-body">
         	
            </div>
          </div>

	</div>

		<div class="col-sm-4">
		   <div class="panel panel-warning">
            <div class="panel-heading">
              <h3 class="panel-title"> <i class="fa fa-info"></i></h3>
            </div>
            <div class="panel-body">
         	
            </div>
          </div>

	</div>

		<div class="col-sm-4">
		   <div class="panel panel-success">
            <div class="panel-heading">
              <h3 class="panel-title"> <i class="fa fa-info"></i></h3>
            </div>
            <div class="panel-body">
         	
            </div>
          </div>

	</div>

</div>

	</div>
</div>

<script type="text/javascript">
		
		$(document).ready(function(){

		});

</script>