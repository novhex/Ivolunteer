	<!-- Javascript files  !-->

<hr>
<p style="text-align:center;">&copy; Ivolunteer <?php echo date('Y'); ?> </p>


	<script type="text/javascript" src="<?php echo base_url('customjs/ivo.js');?>"></script>
	<script type="text/javascript" src="<?php echo base_url('customjs/bootstrapvalidator.js');?>"></script>
	</body>
</html> 